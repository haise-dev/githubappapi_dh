package com.example.githubtest;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.githubtest.models.Repo;
import com.example.githubtest.viewmodel.RepoViewModel;
import java.util.List;

public class ReposFragment extends Fragment {

    private OnRepoSelectedListener callback;
    private RecyclerView recyclerView;
    private RepoAdapter adapter;
    private RepoViewModel repoViewModel;

    // Define the OnRepoSelectedListener interface
    public interface OnRepoSelectedListener {
        void onRepoSelected(String owner, String repoName);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnRepoSelectedListener) {
            callback = (OnRepoSelectedListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnRepoSelectedListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_repos, container, false);

        // Initialize RecyclerView
        recyclerView = view.findViewById(R.id.recycler_view_repos);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new RepoAdapter(new RepoAdapter.OnRepoClickListener() {
            @Override
            public void onRepoClick(Repo repo) {
                onRepositoryClicked(repo); // Call method when item is clicked
            }
        });
        recyclerView.setAdapter(adapter);

        // Set up ViewModel and observe data
        repoViewModel = new ViewModelProvider(this).get(RepoViewModel.class);
        repoViewModel.getRepos().observe(getViewLifecycleOwner(), new Observer<List<Repo>>() {
            @Override
            public void onChanged(List<Repo> repos) {
                adapter.setRepos(repos);
            }
        });

        return view;
    }

    private void onRepositoryClicked(Repo repo) {
        if (callback != null) {
            callback.onRepoSelected(repo.getOwner().getLogin(), repo.getName());
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        callback = null;
    }
}
