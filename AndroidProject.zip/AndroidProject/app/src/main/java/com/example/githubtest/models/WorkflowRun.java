package com.example.githubtest.models;

import com.google.gson.annotations.SerializedName;

public class WorkflowRun {

    @SerializedName("id")
    private long id;

    @SerializedName("name")
    private String name;

    @SerializedName("status")
    private String status;

    @SerializedName("created_at")
    private String createdAt;

    // Getter cho ID
    public long getId() {
        return id;
    }

    // Getter cho tên workflow run
    public String getName() {
        return name;
    }

    // Getter cho trạng thái workflow run
    public String getStatus() {
        return status;
    }

    // Getter cho thời gian tạo
    public String getCreatedAt() {
        return createdAt;
    }
}
