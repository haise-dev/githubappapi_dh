package com.example.githubtest;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import com.example.githubtest.viewmodel.FileContentViewModel;

public class FileContentFragment extends Fragment {

    private static final String ARG_OWNER = "owner";
    private static final String ARG_REPO_NAME = "repo_name";
    private static final String ARG_FILE_PATH = "file_path";

    private FileContentViewModel fileContentViewModel;
    private TextView fileContentTextView;

    public static FileContentFragment newInstance(String owner, String repoName, String filePath) {
        FileContentFragment fragment = new FileContentFragment();
        Bundle args = new Bundle();
        args.putString(ARG_OWNER, owner);
        args.putString(ARG_REPO_NAME, repoName);
        args.putString(ARG_FILE_PATH, filePath);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_file_content, container, false);
        fileContentTextView = view.findViewById(R.id.file_content_text_view);

        fileContentViewModel = new ViewModelProvider(this).get(FileContentViewModel.class);

        if (getArguments() != null) {
            String owner = getArguments().getString(ARG_OWNER);
            String repoName = getArguments().getString(ARG_REPO_NAME);
            String filePath = getArguments().getString(ARG_FILE_PATH);

            fileContentViewModel.loadFileContent(owner, repoName, filePath);
        }

        fileContentViewModel.getFileContent().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(String content) {
                fileContentTextView.setText(content);
            }
        });

        return view;
    }
}
