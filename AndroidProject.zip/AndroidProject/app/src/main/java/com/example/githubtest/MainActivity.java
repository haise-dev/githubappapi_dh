package com.example.githubtest;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements ReposFragment.OnRepoSelectedListener {

    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Setup DrawerLayout and NavigationView
        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.navigation_view);

        // Setup ActionBarDrawerToggle for navigation drawer
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Open the Navigation Drawer when the app starts
        drawerLayout.openDrawer(GravityCompat.START);

        // Load default fragment if none is loaded
        if (savedInstanceState == null) {
            loadFragment(new ReposFragment());
            navigationView.setCheckedItem(R.id.nav_repos);
        }

        // Setup Navigation Drawer item selection
        navigationView.setNavigationItemSelectedListener(menuItem -> {
            Fragment selectedFragment = null;
            int itemId = menuItem.getItemId();

            if (itemId == R.id.nav_repos) {
                selectedFragment = new ReposFragment();
            } else if (itemId == R.id.nav_workflow) {
                selectedFragment = new WorkflowFragment();
            } else if (itemId == R.id.nav_settings) {
                selectedFragment = new SettingsFragment();
            }

            if (selectedFragment != null) {
                loadFragment(selectedFragment);
            }

            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });

        // Set up a custom back press handler using OnBackPressedDispatcher
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else if (getSupportFragmentManager().getBackStackEntryCount() > 1) {
                    getSupportFragmentManager().popBackStack();
                } else {
                    finish(); // Exit the app if no fragments are in the back stack
                }
            }
        });
    }

    /**
     * Loads a new fragment into the fragment container
     *
     * @param fragment The fragment to load
     */
    private void loadFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, fragment);
        fragmentTransaction.addToBackStack(null); // Add fragment to back stack
        fragmentTransaction.commit();
    }

    /**
     * Called when a repository is selected from the ReposFragment
     *
     * @param owner The owner of the repository
     * @param repoName The name of the repository
     */
    @Override
    public void onRepoSelected(String owner, String repoName) {
        RepositoryDetailFragment fragment = RepositoryDetailFragment.newInstance(owner, repoName);
        loadFragment(fragment);
    }
}
