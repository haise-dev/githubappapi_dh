package com.example.githubtest.api;

import com.example.githubtest.models.FileContent;
import com.example.githubtest.models.Repo;
import com.example.githubtest.models.RepoFile;
import com.example.githubtest.models.WorkflowRun;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface GitHubService {

    // Endpoint để lấy danh sách các repo của người dùng
    @GET("user/repos")
    Call<List<Repo>> getUserRepos();

    // Endpoint để lấy danh sách các workflow runs cho một repo cụ thể
    @GET("repos/{owner}/{repo}/actions/runs")
    Call<List<WorkflowRun>> getWorkflowRuns(
            @Path("owner") String owner,
            @Path("repo") String repo
    );


        // Lấy danh sách file trong repository
        @GET("repos/{owner}/{repo}/contents")
        Call<List<RepoFile>> getRepoFiles(@Path("owner") String owner, @Path("repo") String repo);

        // Lấy nội dung file cụ thể
        @GET("repos/{owner}/{repo}/contents/{path}")
        Call<FileContent> getFileContent(
                @Path("owner") String owner,
                @Path("repo") String repo,
                @Path("path") String path
        );
    }


