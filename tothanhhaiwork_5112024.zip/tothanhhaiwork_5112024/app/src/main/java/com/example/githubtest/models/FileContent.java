package com.example.githubtest.models;

import com.google.gson.annotations.SerializedName;

public class FileContent {

    @SerializedName("name")
    private String name;

    @SerializedName("path")
    private String path;

    @SerializedName("type")
    private String type;

    @SerializedName("content")
    private String content;

    @SerializedName("encoding")
    private String encoding;

    public FileContent(String name, String path, String type, String content, String encoding) {
        this.name = name;
        this.path = path;
        this.type = type;
        this.content = content;
        this.encoding = encoding;
    }

    public String getName() {
        return name;
    }

    public String getPath() {
        return path;
    }

    public String getType() {
        return type;
    }

    public String getContent() {
        return content;
    }

    public String getEncoding() {
        return encoding;
    }

    // Giải mã nội dung từ Base64 (vì GitHub trả về nội dung file ở định dạng Base64)
    public String getDecodedContent() {
        if ("base64".equalsIgnoreCase(encoding) && content != null) {
            try {
                byte[] decodedBytes = android.util.Base64.decode(content, android.util.Base64.DEFAULT);
                return new String(decodedBytes, java.nio.charset.StandardCharsets.UTF_8);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
