

*FIRST THING FIRST*: Vì API_TOKEN thuộc dạng thông tin bảo mật,
theo chính sách của github và google drive, 
hay 1 số dạng lưu trữ và chia sẻ file trực tuyến khác là sẽ không được phép chia sẻ
nên để chia sẻ và sử dụng được ae thực hiện các bước sau đây:
- Bước 1: tự generate 1 api_token riêng từ tài khoản github cá nhân
- Bước 2: mở file gradle.properties paste vào cuối cùng, và bấm Sync Now và rồi Run App như bình thường
- Bước 3: Sau khi chỉnh sửa project, muốn chia sẻ cho người khác thì xóa dòng code đó đi và bảo họ đọc hưỡng dẫn này.

Sau khi thực hiện các bước trên thì đọc hướng dẫn dưới này để biết project đã có những gì:


1. Thiết lập Retrofit để kết nối với GitHub API
trong build.gradle.kts ( module: app) đã thêm: 

implementation 'com.squareup.retrofit2:retrofit:2.9.0'
implementation 'com.squareup.retrofit2:converter-gson:2.9.0'


2. Tạo một interface để định nghĩa các endpoints API ( GitHubService.java)
3. Sử dụng API token để xác thực và kết nối:

Sau đó config trong file build.gradle.kts để xác thực kết nối token api đã khai báo:

    defaultConfig {
        applicationId = "com.example.githubtest"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        buildConfigField("String", "GITHUB_API_TOKEN", "\"${project.findProperty("GITHUB_API_TOKEN") ?: ""}\"")

    }

// Phần này để bật tính năng buildConfig

    buildFeatures {
        buildConfig = true  
    }

4. Cho phép kết nối INTERNET để truy cập website github, lấy thông tin từ api đã xác thực (thực hiện trong AndroidManifest.xml)

    <uses-permission android:name="android.permission.INTERNET"/>

5. Tạo giao diện bằng file mainactivity.xml cũng như các file fragment( cụ thể là file fragment_repos.xml và fragment_workflows.xml)
Bên cạnh đó dùng navigation_drawer để tạo mục để navigate giữa các fragment.
ngoài ra, còn có một số thiết kế lặt vặt ở trong:
-res/menu để cấu hình design của navigation navigation_drawer
- các item_repo.xml, item_workflow.xml để generate các repo và workflow sau khi fetch api
- string.xml để hiển thị tên app, tên ảnh avatar và tính năng bật tắt navigation
- fragment setting.xml chưa có gì cả, để mặc định,  cho vào cho có


6. Sử dụng các model( Repo và WorkFlowRun) để khái quát bố cục của dữ liệu hiển thị sau khi fetch api
7. Sử dụng method ViewModel để hiển thị các dữ liệu đó trên các fragment, bằng cách kết nối chúng với nhau bằng Adapter
8. Tạo file APIClient.java là một lớp để quản lý việc cấu hình và khởi tạo Retrofit – một HTTP client giúp kết nối đến API


Cập nhật ngày 5/11/2024:

10. - Trong thư mục model, RepoFile dùng để tạo form cho các file có trong repositories
    - Trong thư mục viewmodel, RepositoriyViewModel giúp nhận form, kết nối với ReposFragment và hiển thị các file trong repositories theo đúng form
    - RepoFileAdapter.java giúp thực hiện các thao tác như bấm vào file hiển thị nội dung file, bấm vào Thư mục repo, hiển thị các file trong repositories
    - một số file xml mới như: fragment_repository_detail.xml, fragment_file_content.xml để hiển thị layout của các file trong repo và nội dung của các file đó lên front-end.



Một số lưu ý: 
- Sử dụng Java, không dùng Klotin
- Muốn thêm dependencies gì thì Chỉ sử dụng buil.gradle.kts(Module: app)
- Sửa cái gì trong file build.gradle.kts và gradle.properties xong thì phải Sync Now

