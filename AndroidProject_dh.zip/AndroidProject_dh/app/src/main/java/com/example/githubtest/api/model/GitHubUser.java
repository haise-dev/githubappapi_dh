package com.example.githubtest.api.model;

import com.google.gson.annotations.SerializedName;

public class GitHubUser {

    @SerializedName("login")
    private String login;

    @SerializedName("id")
    private int id;

    @SerializedName("avatar_url")
    private String avatarUrl;

    @SerializedName("name")
    private String name;

    @SerializedName("company")
    private String company;

    @SerializedName("blog")
    private String blog;

    @SerializedName("location")
    private String location;

    @SerializedName("email")
    private String email;

    @SerializedName("bio")
    private String bio;

    @SerializedName("public_repos")
    private int publicRepos;

    @SerializedName("followers")
    private int followers;

    @SerializedName("following")
    private int following;

    // Add other fields as needed based on the API response

    // Getters for all fields
    public String getLogin() { return login; }
    public int getId() { return id; }
    public String getAvatarUrl() { return avatarUrl; }
    public String getName() { return name; }
    public String getCompany() { return company; }
    public String getBlog() { return blog; }
    public String getLocation() { return location; }
    public String getEmail() { return email; }
    public String getBio() { return bio; }
    public int getPublicRepos() { return publicRepos; }
    public int getFollowers() { return followers; }
    public int getFollowing() { return following; }
}
