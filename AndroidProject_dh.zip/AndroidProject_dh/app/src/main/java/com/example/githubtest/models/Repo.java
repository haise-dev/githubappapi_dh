package com.example.githubtest.models;

public class Repo {
    private String name;
    private String full_name;

    public String getName() {
        return name;
    }

    public String getFullName() {
        return full_name;
    }
}