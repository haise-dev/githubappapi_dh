package com.example.githubtest;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.githubtest.models.WorkflowRun;
import com.example.githubtest.viewmodel.WorkflowViewModel;

import java.util.List;

public class WorkflowFragment extends Fragment {

    private WorkflowViewModel workflowViewModel;
    private RecyclerView recyclerView;
    private WorkflowAdapter workflowAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_workflow, container, false);

        recyclerView = view.findViewById(R.id.recycler_view_workflows);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        workflowAdapter = new WorkflowAdapter();
        recyclerView.setAdapter(workflowAdapter);

        // Khởi tạo ViewModel
        workflowViewModel = new ViewModelProvider(this).get(WorkflowViewModel.class);

        // Quan sát LiveData để cập nhật dữ liệu khi có thay đổi
        workflowViewModel.getWorkflows().observe(getViewLifecycleOwner(), new Observer<List<WorkflowRun>>() {
            @Override
            public void onChanged(List<WorkflowRun> workflows) {
                workflowAdapter.setWorkflows(workflows);
            }
        });

        workflowViewModel.fetchWorkflows("thanhhai_12", "mobiledev2024 ");

        return view;
    }
}
