package com.example.githubtest.ui.login;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.githubtest.R;
import com.example.githubtest.api.ApiClient;
import com.example.githubtest.api.GitHubService;
import com.example.githubtest.api.model.GitHubUser;
import com.example.githubtest.MainActivity; // Ensure to import your MainActivity

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private Button loginButton;
    private ProgressBar loadingProgressBar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize views
        usernameEditText = findViewById(R.id.username);
        loginButton = findViewById(R.id.login);
        loadingProgressBar = findViewById(R.id.loading);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                if (username.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter a username", Toast.LENGTH_SHORT).show();
                    return;
                }

                authenticateUser(username);
            }
        });
    }

    private void authenticateUser(String username) {
        loadingProgressBar.setVisibility(View.VISIBLE);

        GitHubService service = ApiClient.getGitHubService();
        service.getUserByUsername(username).enqueue(new Callback<GitHubUser>() {
            @Override
            public void onResponse(Call<GitHubUser> call, Response<GitHubUser> response) {
                loadingProgressBar.setVisibility(View.GONE);
                if (response.isSuccessful()) {
                    GitHubUser user = response.body();
                    if (user != null) {
                        navigateToProfile(user);
                    } else {
                        showError("No user found.");
                    }
                } else {
                    showError("Invalid username or user not found.");
                }
            }

            @Override
            public void onFailure(Call<GitHubUser> call, Throwable t) {
                loadingProgressBar.setVisibility(View.GONE);
                showError("Error: " + t.getMessage());
            }
        });
    }

    private void navigateToProfile(GitHubUser user) {
        // Show welcome message
        Toast.makeText(this, "Welcome, " + user.getLogin(), Toast.LENGTH_SHORT).show();

        // Create an intent to navigate to MainActivity
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);

        // Pass the username and avatar URL to MainActivity
        intent.putExtra("USERNAME", user.getLogin());
        intent.putExtra("AVATAR_URL", user.getAvatarUrl());

        startActivity(intent);
        finish(); // Close LoginActivity to prevent returning to it
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
