package com.example.githubtest.api;

import com.example.githubtest.api.model.GitHubEmail;
import com.example.githubtest.api.model.GitHubFollower;
import com.example.githubtest.api.model.GitHubUser;
import com.example.githubtest.models.Repo;
import com.example.githubtest.models.WorkflowRun;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface GitHubService {

    // Endpoint to get the list of the user's repositories
    @GET("user/repos")
    Call<List<Repo>> getUserRepos();

    // Endpoint to get the list of workflow runs for a specific repository
    @GET("repos/{owner}/{repo}/actions/runs")
    Call<List<WorkflowRun>> getWorkflowRuns(
            @Path("owner") String owner,
            @Path("repo") String repo
    );

    // Endpoint to fetch the authenticated user's profile details
    @GET("user")
    Call<GitHubUser> getUser();

    @GET("/users/{username}")
    Call<GitHubUser> getUserByUsername(@Path("username") String username);

    // Endpoint to fetch the user's primary email
    @GET("user/emails")
    Call<List<GitHubEmail>> getUserEmails();

    // Endpoint to fetch the user's followers
    @GET("user/followers")
    Call<List<GitHubFollower>> getUserFollowers();
}
