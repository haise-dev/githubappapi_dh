package com.example.githubtest.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.githubtest.api.ApiClient;
import com.example.githubtest.api.GitHubService;
import com.example.githubtest.models.WorkflowRun;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.util.Log;

public class WorkflowViewModel extends ViewModel {

    private final MutableLiveData<List<WorkflowRun>> workflows = new MutableLiveData<>();
    private final MutableLiveData<String> errorMessage = new MutableLiveData<>();
    private final GitHubService gitHubService;

    public WorkflowViewModel() {
        gitHubService = ApiClient.getGitHubService();
    }


    public LiveData<List<WorkflowRun>> getWorkflows() {
        return workflows;
    }


    public LiveData<String> getErrorMessage() {
        return errorMessage;
    }


    public void fetchWorkflows(String owner, String repo) {
        gitHubService.getWorkflowRuns(owner, repo).enqueue(new Callback<List<WorkflowRun>>() {
            @Override
            public void onResponse(Call<List<WorkflowRun>> call, Response<List<WorkflowRun>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    workflows.setValue(response.body());
                } else {
                    errorMessage.setValue("Failed to load workflows: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<List<WorkflowRun>> call, Throwable t) {
                Log.e("WorkflowViewModel", "API call failed", t);
                errorMessage.setValue("Error fetching workflows: " + t.getMessage());
            }
        });
    }
}
