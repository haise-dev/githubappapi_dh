package com.example.githubtest;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.githubtest.api.ApiClient;
import com.example.githubtest.api.GitHubService;
import com.example.githubtest.api.model.GitHubUser;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileActivity extends AppCompatActivity {

    private TextView usernameTextView;
    private TextView followersTextView;
    private ImageView avatarImageView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Initialize views
        avatarImageView = findViewById(R.id.avatarImageView);
        usernameTextView = findViewById(R.id.usernameTextView);
        followersTextView = findViewById(R.id.followersTextView);

        // Fetch user data
        fetchUserProfile();
    }

    private void fetchUserProfile() {
        GitHubService service = ApiClient.getGitHubService();
        service.getUser().enqueue(new Callback<GitHubUser>() {
            @Override
            public void onResponse(Call<GitHubUser> call, Response<GitHubUser> response) {
                if (response.isSuccessful()) {
                    GitHubUser user = response.body();
                    if (user != null) {
                        // Update UI with user data
                        usernameTextView.setText(user.getLogin());
                        followersTextView.setText(String.format("Followers: %d", user.getFollowers()));
                        Glide.with(ProfileActivity.this)
                                .load(user.getAvatarUrl())
                                .into(avatarImageView);
                    }
                } else {
                    Toast.makeText(ProfileActivity.this, "Failed to fetch user profile", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GitHubUser> call, Throwable t) {
                Toast.makeText(ProfileActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
