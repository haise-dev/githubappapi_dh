package com.example.githubtest.api.model;

public class GitHubFollower {
    private String login;
    private int id;

    // Getters
    public String getLogin() {
        return login;
    }

    public int getId() {
        return id;
    }
}
