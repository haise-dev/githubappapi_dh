Những điều tôi đã làm: 
1. Thiết lập Retrofit để kết nối với GitHub API
trong build.gradle.kts ( module: app) đã thêm: 

implementation 'com.squareup.retrofit2:retrofit:2.9.0'
implementation 'com.squareup.retrofit2:converter-gson:2.9.0'


2. Tạo một interface để định nghĩa các endpoints API ( GitHubService.java)
3. Sử dụng API token để xác thực và kết nối:

Trong gradle.properties tôi đã khai báo

GITHUB_API_TOKEN=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

Sau đó config trong file build.gradle.kts để xác thực kết nối token api đã khai báo:

    defaultConfig {
        applicationId = "com.example.githubtest"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        buildConfigField("String", "GITHUB_API_TOKEN", "\"${project.findProperty("GITHUB_API_TOKEN") ?: ""}\"")

    }

// Phần này để bật tính năng buildConfig

    buildFeatures {
        buildConfig = true  
    }

4. Cho phép kết nối INTERNET để truy cập website github, lấy thông tin từ api đã xác thực (thực hiện trong AndroidManifest.xml)

    <uses-permission android:name="android.permission.INTERNET"/>

5. Tạo giao diện bằng file mainactivity.xml cũng như các file fragment( cụ thể là file fragment_repos.xml và fragment_workflows.xml)
Bên cạnh đó dùng navigation_drawer để tạo mục để navigate giữa các fragment.
ngoài ra, còn có một số thiết kế lặt vặt ở trong:
-res/menu để cấu hình design của navigation navigation_drawer
- các item_repo.xml, item_workflow.xml để generate các repo và workflow sau khi fetch api
- string.xml để hiển thị tên app, tên ảnh avatar và tính năng bật tắt navigation
- fragment setting.xml chưa có gì cả, để mặc định,  cho vào cho có


6. Sử dụng các model( Repo và WorkFlowRun) để khái quát bố cục của dữ liệu hiển thị sau khi fetch api
7. Sử dụng method ViewModel để hiển thị các dữ liệu đó trên các fragment, bằng cách kết nối chúng với nhau bằng Adapter
8. Tạo file APIClient.java là một lớp để quản lý việc cấu hình và khởi tạo Retrofit – một HTTP client giúp kết nối đến API



Một số lưu ý: 
- Sử dụng Java, không dùng Klotin
- Muốn thêm dependencies gì thì Chỉ sử dụng buil.gradle.kts(Module: app)
- Sửa cái gì trong file build.gradle.kts và gradle.properties xong thì phải Sync Now
